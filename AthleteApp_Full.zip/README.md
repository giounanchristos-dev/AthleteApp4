Full project ready. Upload extracted files to GitHub (do not upload zip). Use Codemagic workflow 'android-app'.
