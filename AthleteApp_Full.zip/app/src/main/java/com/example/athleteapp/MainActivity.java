package com.example.athleteapp;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    Button btnManage, btnRecord, btnAppts, btnReports;
    LinearLayout container;
    ArrayList<String> athletes = new ArrayList<>();
    ArrayList<Record> records = new ArrayList<>();
    ArrayList<Appointment> appointments = new ArrayList<>();
    Gson gson = new Gson();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnManage = findViewById(R.id.btnManage);
        btnRecord = findViewById(R.id.btnRecord);
        btnAppts = findViewById(R.id.btnAppts);
        btnReports = findViewById(R.id.btnReports);
        container = findViewById(R.id.container);
        loadAll();
        btnManage.setOnClickListener(v -> showManage());
        btnRecord.setOnClickListener(v -> showRecord());
        btnAppts.setOnClickListener(v -> showAppointments());
        btnReports.setOnClickListener(v -> showReports());
        showManage();
    }

    private void saveAll() {
        getPreferences(MODE_PRIVATE).edit().putString("athletes", gson.toJson(athletes)).apply();
        getPreferences(MODE_PRIVATE).edit().putString("records", gson.toJson(records)).apply();
        getPreferences(MODE_PRIVATE).edit().putString("appointments", gson.toJson(appointments)).apply();
    }
    private void loadAll() {
        String a = getPreferences(MODE_PRIVATE).getString("athletes", null);
        String r = getPreferences(MODE_PRIVATE).getString("records", null);
        String p = getPreferences(MODE_PRIVATE).getString("appointments", null);
        Type listString = new TypeToken<ArrayList<String>>(){}.getType();
        Type recType = new TypeToken<ArrayList<Record>>(){}.getType();
        Type apptType = new TypeToken<ArrayList<Appointment>>(){}.getType();
        if (a != null) athletes = gson.fromJson(a, listString);
        if (r != null) records = gson.fromJson(r, recType);
        if (p != null) appointments = gson.fromJson(p, apptType);
    }

    private void showManage() {
        container.removeAllViews();
        View v = getLayoutInflater().inflate(R.layout.manage_athletes, null);
        EditText input = v.findViewById(R.id.inputName);
        Button btnAdd = v.findViewById(R.id.btnAdd);
        ListView list = v.findViewById(R.id.listAthletes);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, athletes);
        list.setAdapter(adapter);
        btnAdd.setOnClickListener(x -> {
            String name = input.getText().toString().trim();
            if (name.length() > 0) { athletes.add(name); input.setText(""); adapter.notifyDataSetChanged(); saveAll(); }
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            String name = athletes.get(position);
            new android.app.AlertDialog.Builder(this).setTitle("Διαγραφή").setMessage("Διαγράφεις τον/την " + name + "?").setPositiveButton("Ναι", (d, i) -> { athletes.remove(position); adapter.notifyDataSetChanged(); saveAll(); }).setNegativeButton("Όχι", null).show();
            return true;
        });
        container.addView(v);
    }

    private void showRecord() {
        container.removeAllViews();
        View v = getLayoutInflater().inflate(R.layout.record_presence, null);
        EditText inputDate = v.findViewById(R.id.inputDate);
        Spinner spinnerType = v.findViewById(R.id.spinnerType);
        ListView list = v.findViewById(R.id.listRecordAthletes);
        ArrayAdapter<String> tAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Δρομικό","Σφαίρα","Βάρη","Τεστ"});
        spinnerType.setAdapter(tAdapter);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, athletes);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            String athlete = athletes.get(position);
            String date = inputDate.getText().toString().trim();
            int typeIdx = spinnerType.getSelectedItemPosition();
            if (date.length() < 8) { Toast.makeText(this, "Γράψε ημερομηνία YYYY-MM-DD", Toast.LENGTH_SHORT).show(); return; }
            String[] types = {"dr","sf","br","test"};
            Record rec = new Record(athlete, date, types[typeIdx]);
            records.add(rec);
            Toast.makeText(this, "Καταγράφηκε " + athlete, Toast.LENGTH_SHORT).show();
            saveAll();
        });
        container.addView(v);
    }

    private void showAppointments() {
        container.removeAllViews();
        View v = getLayoutInflater().inflate(R.layout.appointments, null);
        EditText inputDate = v.findViewById(R.id.inputAppDate);
        EditText inputTime = v.findViewById(R.id.inputAppTime);
        Spinner spinnerType = v.findViewById(R.id.spinnerAppType);
        ListView athletesList = v.findViewById(R.id.listApptAthletes);
        Button btnAdd = v.findViewById(R.id.btnAddAppt);
        ListView listAppts = v.findViewById(R.id.listAppointments);
        ArrayAdapter<String> tAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"Δρομικό","Σφαίρα","Βάρη","Τεστ"});
        spinnerType.setAdapter(tAdapter);
        ArrayAdapter<String> athletesAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice, athletes);
        athletesList.setAdapter(athletesAdapter);
        athletesList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        ArrayAdapter<String> apptsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, getApptStrings());
        listAppts.setAdapter(apptsAdapter);
        btnAdd.setOnClickListener(x -> {
            String date = inputDate.getText().toString().trim();
            String time = inputTime.getText().toString().trim();
            int typeIdx = spinnerType.getSelectedItemPosition();
            if (date.length() < 8 || time.length() < 1) { Toast.makeText(this, "Συμπλήρωσε ημερομηνία & ώρα", Toast.LENGTH_SHORT).show(); return; }
            ArrayList<String> sel = new ArrayList<>();
            for (int i=0;i<athletes.size();i++){ if (athletesList.isItemChecked(i)) sel.add(athletes.get(i)); }
            String[] types = {"dr","sf","br","test"};
            Appointment ap = new Appointment(date, time, types[typeIdx], sel);
            appointments.add(ap);
            apptsAdapter.clear(); apptsAdapter.addAll(getApptStrings()); apptsAdapter.notifyDataSetChanged(); saveAll();
        });
        container.addView(v);
    }

    private void showReports() {
        container.removeAllViews();
        View v = getLayoutInflater().inflate(R.layout.reports, null);
        EditText inputMonth = v.findViewById(R.id.inputMonth);
        Button btnGen = v.findViewById(R.id.btnGenerate);
        TextView tv = v.findViewById(R.id.tvReport);
        btnGen.setOnClickListener(x -> {
            String month = inputMonth.getText().toString().trim();
            if (month.length() < 7) { Toast.makeText(this, "Γράψε μήνα YYYY-MM", Toast.LENGTH_SHORT).show(); return; }
            String report = generateMonthlyReport(month);
            tv.setText(report);
        });
        container.addView(v);
    }

    private String generateMonthlyReport(String month) {
        Map<String, Map<String, Integer>> map = new LinkedHashMap<>();
        for (String a : athletes) { Map<String,Integer> m = new HashMap<>(); m.put("dr",0); m.put("sf",0); m.put("br",0); m.put("test",0); map.put(a,m); }
        for (Record r : records) { if (r.date != null && r.date.startsWith(month)) { Map<String,Integer> m = map.get(r.athlete); if (m != null) m.put(r.type, m.get(r.type)+1); } }
        StringBuilder sb = new StringBuilder();
        sb.append("Μηνιαία Αναφορά για ").append(month).append("\n\n");
        for (String a : map.keySet()) { Map<String,Integer> m = map.get(a); int total = m.get("dr")+m.get("sf")+m.get("br")+m.get("test"); sb.append(a).append(": ").append(total).append(" (Δ:" + m.get("dr") + ", Σ:" + m.get("sf") + ", Β:" + m.get("br") + ", T:" + m.get("test") + ")\n"); }
        return sb.toString();
    }

    private List<String> getApptStrings() { List<String> out = new ArrayList(); for (Appointment a : appointments) { out.add(a.date + " " + a.time + " — " + a.type + " : " + String.join(",", a.athletes)); } return out; }

    static class Record { String athlete; String date; String type; Record(String athlete, String date, String type) { this.athlete=athlete; this.date=date; this.type=type; } }
    static class Appointment { String date; String time; String type; ArrayList<String> athletes; Appointment(String d,String t,String ty,ArrayList<String> a){ date=d; time=t; type=ty; athletes=a; } }
}
